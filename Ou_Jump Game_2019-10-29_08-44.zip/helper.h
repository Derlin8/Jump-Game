#ifndef helper_h
#define helper_h

#include <iostream>
#include <vector>
#include <cctype>
using namespace std;
void solve(vector<int> &res , vector<int>& input , int pos , int target , vector<bool> & visited , vector<int>& final , int& min);

#endif /* helper_h */