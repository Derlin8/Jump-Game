#include "helper.h"

int main(int argc, char** argv) {
    if(argc == 0){
        cout << "There is no solution to the given game." << endl;
        return 0;
    }
    
    vector<int> inputVec,  outputVec;
    vector<int> res;
    vector<int> final;
    vector<bool> visited;
    int initialMin = 999;
    for (int i = 1; i < argc; i++) {
        inputVec.emplace_back(stoi(argv[i]));
    }
    if(inputVec.size() == 0){
        cout << "There is no solution to the given game." << endl;
        return 0;
    }
    for(unsigned int i = 0 ; i < inputVec.size() ; i++){
        visited.push_back(false);
    }
    solve(res,inputVec,0,(int)inputVec.size()-1,visited, final , initialMin);
    if(final.size() == 0){
        cout << "There is no solution to the given game." << endl;
        return 0;
    }
    cout << "The solution is: {";
    for(auto s : final){
        if (s == final.back()) {
            cout << s;
            break;
        }
        cout << s << ", ";
    }
    cout << "}" << endl;
    //cout << " all done " << endl;
    
}
