#include "helper.h"
//Jump game passes in values
void solve(vector<int> &res , vector<int>& input , int pos , int target , vector<bool> & visited , vector<int>& final , int& min){
    
    visited[pos] = true;
    
    if(pos < 0 || pos > target) return; //return if out of range
    if(pos == target){ // if is target , print path
        res.push_back(pos);
        int pathSize = (int)res.size();
        if(pathSize < min){
            final.clear();
            min = pathSize;
            for(auto s: res){
                final.push_back(s);
            }
        }
        res.pop_back();
        visited[pos] = false;
        return;
    }
    res.push_back(pos); // save the index
    if(input[pos] == 0) return;
    if( (pos - input[pos]) >= 0 && (pos - input[pos]) <= target &&  visited[pos - input[pos]] == false){
        solve(res,input,pos - input[pos],target,visited,final , min); //Go Left  if not visited and in range
    }
    visited[pos] = false;
    if( (pos + input[pos]) >= 0 && (pos + input[pos]) <= target &&  visited[pos + input[pos]] == false){
        solve(res,input,pos+ input[pos] ,target,visited, final , min); // Go right  if not visited
    }
    res.pop_back();
    //Compare path
    //return path
}
